#ifndef NAME_H
#define NAME_H

#include <string>

struct Name
{
public:
	std::string mFirstName;
	std::string mLastName;
};

#endif NAME_H